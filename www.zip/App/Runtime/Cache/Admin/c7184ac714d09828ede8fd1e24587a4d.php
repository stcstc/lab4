<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title></title>
        <link rel='stylesheet' type='text/css' href='__PUBLIC__/css/style.css'>
            <style>
                html{overflow-x : hidden;}
            </style>
            <base target="main" />
    </head>

    <body >
        <div id="menu" class="menu">
            <table class="list shadow" cellpadding=0 cellspacing=0 >
                <tr>
                    <td height='3' colspan=1 class="topTd" ></td>
                </tr>
                <tr class="row" >
                    <th class="tCenter space"><img SRC="__PUBLIC__/images/home.gif" WIDTH="16" HEIGHT="16" BORDER="0" ALT="" align="absmiddle"> 应用中心</th>
                </tr>
				<tr class="row " >
					<td><div style="margin:0px 5px"><img SRC="../Public/images/comment.gif" WIDTH="9" HEIGHT="9" BORDER="0" align="absmiddle" ALT=""> <a href="__GROUP__/Form/index/">数据管理</a></div></td>
				</tr>
                <tr>
                    <td height='3' colspan=1 class="bottomTd"></td>
                </tr>
            </table>
        </div>
    </body>
</html>
<?php if (!defined('THINK_PATH')) exit();?> <style>
 body{font-family:tahoma}
 div.footer{ clear:both; padding:8px 0px; width:100%; text-align:center; font:normal normal normal 11px Verdana,Geneva,Arial,Helvetica,sans-serif; background-color:#464646; border-top:2px solid silver; color:silver}
div.footer a{color:white; text-decoration:none; border-bottom:1px dotted}
div.footer a:hover{color:silver; text-decoration:none; border-bottom:1px dotted}
.think_run_time{text-align:center; width:100%;font-size:12px;}
</style>
<!-- 版权信息区域 -->
<div id="footer" class="footer" >Powered by ThinkPHP <?php echo (THINK_VERSION); ?> | Template designed by <a target="_blank" href="http://www.thinkphp.cn">ThinkPHP</a> <span id="run"></span>
</div>
</body>
</html>